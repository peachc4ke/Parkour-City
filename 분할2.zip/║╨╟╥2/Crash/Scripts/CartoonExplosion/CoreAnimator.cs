﻿
namespace RavingBots.CartoonExplosion
{
	public class CoreAnimator : RadialAnimator
	{ }
}