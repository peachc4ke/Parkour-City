﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkyManager : MonoBehaviour
{
    public Material skyOne;
    public Material skyTwo;
    public Material skyThree;

    public float RotateSpeed = 1.2f;

    void Start()
    {
        RenderSettings.skybox = skyOne;
    }
     
    void Update()
    {
        RenderSettings.skybox.SetFloat("_Rotation", Time.time * RotateSpeed);
    }
}
