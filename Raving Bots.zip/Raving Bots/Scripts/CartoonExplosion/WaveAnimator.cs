﻿
namespace RavingBots.CartoonExplosion
{
	public class WaveAnimator : RadialAnimator
	{ }
}