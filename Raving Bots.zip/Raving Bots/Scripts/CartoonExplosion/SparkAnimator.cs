﻿
namespace RavingBots.CartoonExplosion
{
	public class SparkAnimator : FragmentAnimator
	{ }
}
